<form action="/send/code">
  <label for="code">Код подтверждения:</label>
  <input id="code" type="text" name="code" required>
  <input id="code" type="hidden" name="login" value="<?php echo e($login); ?>" required>
  <button type="submit">ok</button>
</form><?php /**PATH C:\OpenServer2\domains\t-spam-bot.loc\resources\views/getCode.blade.php ENDPATH**/ ?>