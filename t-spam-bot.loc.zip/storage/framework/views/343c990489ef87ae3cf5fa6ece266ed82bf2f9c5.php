

<?php $__env->startSection('content'); ?>
    <router-view />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.controlPanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer2\domains\t-spam-bot.loc\resources\views/main.blade.php ENDPATH**/ ?>