<template>
  <juge-layout>
    <div>
      asd
    </div>
  </juge-layout>
</template>

<script>
export default {

}
</script>

<style scoped>
  div{
    height: 600px;
  }
</style>