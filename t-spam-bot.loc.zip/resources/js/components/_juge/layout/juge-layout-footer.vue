<template>
  <div class="mt-4">
    <span>
      © footer
    </span>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
div{
  background-color: #ebebeb;
  display: flex;
  justify-content: center;
}
</style>