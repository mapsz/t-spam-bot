<template>
  <div>
    <juge-layout>
      
      <center>
        <h1>404</h1>
        <img src="/img/404.gif" alt="">
      </center>

    </juge-layout>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>