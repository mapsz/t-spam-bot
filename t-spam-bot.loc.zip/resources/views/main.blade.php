@extends('layouts.controlPanel')

@section('content')
    <router-view />
@endsection
